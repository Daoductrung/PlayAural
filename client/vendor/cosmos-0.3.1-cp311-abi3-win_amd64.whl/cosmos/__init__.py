from .cosmos import *

__doc__ = cosmos.__doc__
if hasattr(cosmos, "__all__"):
    __all__ = cosmos.__all__